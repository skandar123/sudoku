# Sudoku - AI PROJECT

## Setting up
To clone the project in your local machine

```git clone https://github.com/bansd/Sudoku.git```

Create a new branch on your local

```git checkout -b "your-branch-name"```

## Once done...

Perform following steps
In your project directory,

```
git add <files to be added>
git commit -m "Commit message"
git push origin your-branch-name
```

Note: you can't push directly to master branch, Create a PR and review with your classmates

